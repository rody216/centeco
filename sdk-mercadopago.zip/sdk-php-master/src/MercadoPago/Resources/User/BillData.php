<?php

namespace MercadoPago\Resources\User;

/** BillData class. */
class BillData
{
    /** Indicates whether the user accepts credit notes (true/false). */
    public ?bool $accept_credit_note;
}
