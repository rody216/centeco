<?php

namespace MercadoPago\Resources\MerchantOrder;

class ReceiverAddressCountry
{
    /** Country ID. */
    public ?string $id;

    /** Country name. */
    public ?string $name;
}
