<?php

namespace MercadoPago\Resources\MerchantOrder;

class ReceiverAddressCity
{
    /** City ID. */
    public ?string $id;

    /** City name. */
    public ?string $name;
}
