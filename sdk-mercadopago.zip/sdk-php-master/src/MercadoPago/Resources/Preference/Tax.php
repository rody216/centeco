<?php

namespace MercadoPago\Resources\Preference;

/** Tax class. */
class Tax
{
    /** Tax type. */
    public ?string $type;

    /** Tax value. */
    public ?float $value;
}
