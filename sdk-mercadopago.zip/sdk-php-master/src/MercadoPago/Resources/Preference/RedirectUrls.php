<?php

namespace MercadoPago\Resources\Preference;

/** Redirect URLs class. */
class RedirectUrls extends Urls
{
}
