<?php

namespace MercadoPago\Resources\Common;

/** City class. */
class City
{
    /** City ID. */
    public ?string $id;

    /** City name. */
    public ?string $name;
}
